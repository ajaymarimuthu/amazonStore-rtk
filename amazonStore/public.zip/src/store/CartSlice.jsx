import { createSlice } from "@reduxjs/toolkit";

const initialCartState={
    cartProducts:[],
    amount:0
}

const cartSlice=createSlice({
    name: 'CartItems',
    initialState:initialCartState,


    reducers: {

        addToCart(state,action){
            state.cartProducts.push(action.payload);
        }

    }
    
})


export default cartSlice.reducer;
export const cartActions=cartSlice.actions;