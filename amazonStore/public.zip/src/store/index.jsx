import { configureStore } from "@reduxjs/toolkit";
import homeReducer from './HomeSlice'

import CartReducer from './CartSlice'



const store=configureStore({

    reducer:{
        home:homeReducer,
        cart:CartReducer
    }


})

export default store;