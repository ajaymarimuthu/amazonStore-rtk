import React, { useEffect } from 'react'

import { useDispatch, useSelector } from "react-redux"


import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import {  Button,CardActionArea, CardActions } from '@mui/material';
import './Home.css'

// import Button from '../Button/Button'

import { fetchProducts } from '../../store/HomeSlice';
import addToCart from '../../store/CartSlice'
// import { cartActions } from '../../store/CartSlice';


import { Link } from "react-router-dom"

function Home() {

    const dispatch = useDispatch();
    const products = useSelector(state => state.home);

   const handelAddToCart = (product) =>{
    console.log("hiiiiii");
      dispatch(addToCart(product));
    // console.log(product);
    
   }


    useEffect(() => {

        dispatch(fetchProducts())
        console.log(products);


    }, [])


    return (
        <div className='home'>

            <h1 className='home-title'>Products</h1>
            <div className="home-products">
                {products.products.map((p) => {
                    return (

                        <Card key={p.id} sx={{ maxWidth: 300 }} className="card">
                            <CardActionArea >
                                <CardMedia
                                    className='media'

                                    component="img"
                                    height="250"
                                    image={p.image}
                                    sx={{ maxWidth: 190 }}
                                    alt="green iguana"
                                />
                                <CardContent>
                                    <Typography gutterBottom variant="h6" component="div">
                                        {p.title.substring(0,20)}
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        {p.category}

                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">

                                        {p.price}
                                    </Typography>
                                </CardContent>
                            </CardActionArea>
                            <CardActions className='productcomponent-button'>
                                <Button size="small"
                                onClick={()=> handelAddToCart(p)}
                                 className='button-btn' >
                                    {/* <Link to={`/product/${p.id}`}  > */}
                                        
                                    Add to Cart
                                        {/* <Button>  Add to Cart</Button> */}
                                      
                                    {/* </Link> */}
                                </Button>
                            </CardActions>

                        </Card>
                    )
                })
                }
            </div>





            {/* {products.loading && <div>Loading....</div>}
            {!products.loading && products.error ? <div>Error...{products.error}</div> : null} */}
 
   



        </div>
    )
}

export default Home