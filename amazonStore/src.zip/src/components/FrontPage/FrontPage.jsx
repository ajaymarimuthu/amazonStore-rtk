// import React from 'react'
// import './FrontPage.css'

// function FrontPage() {
//   return (
//     <div className='frontpage'>
//         <div>FrontPage</div>
//         <div>FrontPage</div>
//         <div>FrontPage</div>
//         <div>FrontPage</div>
//         <div>FrontPage</div>
//         <div>FrontPage</div>
        
//     </div>
//   )
// }

// export default FrontPage