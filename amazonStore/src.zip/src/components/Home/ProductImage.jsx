// import React from 'react'

// function ProductImage({img}) {
//   return (
//     <div>
        
//         <img src={img} effec="blur" />
//     </div>
//   )
// }

// export default ProductImage